**本包内容**：`SKILL.md`（技能定义）+ `references/`（30+ 份数据参考）+ `scripts/`（数十个纯标准库 Python 脚本）+ `examples/`（范本）+ `agents/worldstip-travel-planner.md`（智能体提示词）。

**版本**：v0.1.27　**大小**：见下载卡　**许可**：MIT
## 扣子（Coze）安装方式

Coze 目前没有「markdown 技能 zip」直接导入通道，推荐用「Bot + 知识库」方式落地本技能：

1. 在 https://www.coze.cn 创建一个 **Bot**（智能体）。
2. 把本包 `SKILL.md` 的**正文**（去掉 YAML 前置 `---` 段）粘贴到 Bot 的「人设与回复逻辑（系统提示）」。
3. 把 `references/` 下的 JSON 拆条或整份作为「知识库」上传（也可只上传你常去区域相关的几份）。
4. 在「技能」里开启**联网搜索**，用于天气/票价/签证等易变信息核验。
5. 开场白可用 `agents/worldstip-travel-planner.md` 里的 `defaultInitPrompt`。

> 提示：Coze 的 Bot 提示词上限较长，若超长可只保留 SKILL.md 的「定位 / 核心能力 / 工作流程 / 输出规范 / 注意事项」五节。
