# WorldsTip 旅行与摩旅规划大师 · 专家包（v0.2.1）

> 根标志：`.codebuddy-plugin/plugin.json`；内嵌技能真实落盘于 `skills/worldstip-travel-planner/`，
> 含完整 `SKILL.md`（497 行）。

## 这一版是什么

融合版：`worldstip-travel-planner` v0.1.49 的行程编排底座 + `worldstip-moto-fun`
v0.1.3 的摩旅数据引擎，合成单一技能 v0.2.1。

| 层 | 来源 | 说明 |
|---|---|---|
| 编排层（行程/住宿/可行性/出册） | travel v0.1.49 | 端到端出方案，10 章输出契约 |
| 数据层（路线/城市/景点/商圈） | moto-fun v0.1.3 | 摩旅路线与城市消费数据，离线夹具可复现 |
| 路由层 | 双入口 | `scripts/route.py` 判总意图；`scripts/motofun_route.py` 判骑行/商圈意图 |

## 结构

```
.codebuddy-plugin/plugin.json          根标志（解析入口）
agents/worldstip-travel-planner-expert.md     角色定义（标题行版本 v0.2.1）
skills/worldstip-travel-planner/              内嵌技能（完整 SKILL.md + scripts/references/docs）
avatars/worldstip-travel-planner-expert.png
README.md                              本文件
```

## 版本三处一致

`plugin.json` 的 `version` = `0.2.1` / 本 README 标题 `v0.2.1` / agent 标题行 `v0.2.1`。
内嵌技能自带的版本号不随专家包升，保持 0.2.1（两者同版，属融合首发）。

## 上传

本目录打成的 zip 传「专家 / 资产包」入口。若传的是「技能」入口，
改用同批产出的 `worldstip-travel-planner-v0.2.1-fused.zip`（根 `SKILL.md`，无 `skills/` 前缀）。

## 解压体积

平台上限 3 MiB = 3145728 B，按解压后各条目大小求和计。本包实测见构建输出之
`unzipped` 字段；超限时的处置是动数据而非动结构，改法需人工确认。

不承诺过审；平台审核结论以平台通知为准。
