# 百度 DuMate 平台导入说明

本技能包与 SkillHub / WorkBuddy 同源，**直接读取根目录 `SKILL.md`**，无需改造。

## 导入方式
1. 解压本包，得到含 `SKILL.md` 的技能根目录。
2. 在百度 DuMate 桌面 AI 智能体平台，选择「导入技能 / 本地技能」，指向该根目录。
3. DuMate 会按 `SKILL.md` 的 frontmatter（name / description / allowed-tools / license）识别并加载。

## 版本与授权
- 内部开发版本：**0.2.273**（全平台统一，杜绝版本错位）。
- 许可：MIT，附加反蒸馏条款（见 `ANTI_DISTILL.md`）：禁止未授权搬运、二次分发、用于模型训练/蒸馏。
- 归属：WorldsTip by MrdT。
