**本包内容**：`SKILL.md`（技能定义）+ `references/`（30+ 份数据参考）+ `scripts/`（数十个纯标准库 Python 脚本）+ `examples/`（范本）+ `agents/worldstip-travel-planner.md`（智能体提示词）。

**版本**：v0.1.30　**大小**：见下载卡　**许可**：MIT
## 百度搭子 / 文心智能体 安装方式

百度系智能体平台（文心智能体 / 搭子）暂未开放标准「技能 zip」导入，推荐「智能体 + 知识库」方式：

1. 在百度智能体平台创建一个智能体。
2. 把本包 `SKILL.md` 的**正文**作为「系统提示词」粘贴。
3. 把 `references/` 关键 JSON（如 destinations / visa_rules / moto_rules / rv_logistics）作为「文档/知识库」上传。
4. 开启联网能力，用于易变信息核验。
5. 开场白用 `agents/worldstip-travel-planner.md` 里的初始化提示。
