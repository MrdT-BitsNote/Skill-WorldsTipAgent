# worldstip-travel-planner-expert

百度搭子专家套件（Plugin）。面向自助旅行、自驾、摩旅与家庭出行用户，串联需求澄清、意图路由、行程骨架、交通住宿比选、安全门禁与预算核算，输出一份可直接照着走的紧凑行程小册子。

## 结构

```text
worldstip-travel-planner-expert/
├── .claude-plugin/
│   └── plugin.json                 # 入口声明 + 能力清单
├── agents/
│   └── worldstip-travel-planner-expert.md   # 入口智能体：角色/边界/路由/流程/红线
├── skills/
│   └── worldstip-travel-planner/   # 技能：SKILL.md + tests/cases.json + scripts/ + references/
└── README.md
```

## 依赖

- 无连接应用强依赖。`agents[].connectors` 与 `mcpServers` 均为空数组，套件在未连接任何应用的条件下可完整运行。
- 易变事实（票价、班次、开放时间、签证政策、路况）在无联网工具时按 `partial` 降级：标注未核验，输出灰灯与查询去向，不编造结论。
- 技能内脚本为 Python 3 标准库实现，无第三方依赖；脚本缺失或沙箱不支持执行时按 `degrade` 处理，改由技能正文的规则表直接推理。

## 验证方式

1. `.claude-plugin/plugin.json` 为合法 JSON，`name` 与目录名一致，`entry` 可在 `agents[].name` 中找到。
2. `agents[].prompt` 与 `agents[].skills` 指向的路径真实存在。
3. 技能 `SKILL.md` 的 `name` 与目录名、`plugin.json` 声明一致。
4. `skills/worldstip-travel-planner/tests/cases.json` 含 14 条用例，覆盖 `happy_path`、`negative`、`fallback`、`confirm` 四类。
5. 包内无凭证、无隐私数据、无缓存与临时文件、无平台不支持的文件类型（仅 .md/.json/.py/.svg）。

## 版本

- 套件版本：0.2.1
- 内嵌技能版本：0.2.1（技能版本独立演进，不随套件升级）
- 变更记录见技能目录下 `CHANGELOG.md`。

## 已知边界

- 平台当前一期不支持子智能体与套件内置本地连接服务，本套件未使用这两项能力。
- 本地数据集覆盖中国大陆主要城市与线路，未覆盖区域在输出中标注「未收录」，不回退为推测。
